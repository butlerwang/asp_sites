﻿$("document").ready(function(){
	$(".nav li").eq(4).css("margin-left","284px");
	$(".nav li:first-child").css("padding-left","0px");
	$(".nav li:last-child").css("padding-right","0px");

    
    $(".proListPicUl li:nth-child(3n)").css("margin-right","0px");   	
	$(".proListPicUl li").hover(function(){
		$(this).find(".zoom").css("display","block");
		$(this).find(".intro a").css("border-bottom","3px solid #cb4646");
	},function(){
		$(this).find(".zoom").css("display","none");
		$(this).find(".intro a").css("border-bottom","3px solid #ffffff");
	})
	
	$(".newsListDl:nth-child(2n)").css("margin-right","0px");
	$(".quesListDl:nth-child(2n)").css("margin-right","0px");
	
    $(".contactnr p:nth-child(1)").css("background","url(/theme/TP000193/images/mobile.jpg) 30px center no-repeat");
    $(".contactnr p:nth-child(2)").css("background","url(/theme/TP000193/images/map.jpg) 3px center no-repeat");
    $(".contactnr p:nth-child(3)").css("background","url(/theme/TP000193/images/tel.jpg) 27px center no-repeat");
    $(".contactnr p:nth-child(4)").css("background","url(/theme/TP000193/images/mail.jpg) 0px center no-repeat");
	$(".contactnr p:nth-child(2n)").css("width","534px");
	$(".contactnr p:nth-child(2n)").css("padding-left","44px");
  
	$(".leftContact dl:last").find(" dd").css("line-height","28px"); 
	


   $(".site").hover(function(){
  	  $(this).css("background","url(/theme/TP000193/images/site2.png) left top no-repeat");
   },function(){
      $(this).css("background","url(/theme/TP000193/images/site.png) left top no-repeat");
   });
  
  
   $('.backTop').click(function(){
		$('body,html').animate({scrollTop:0},500)
	});
   $('.codepic').hover(function(){$('.code').fadeIn()},function(){$('.code').fadeOut()});
	$('.backup').click(function(){
		$('body,html').animate({scrollTop:0},500)
	});
	$(".backup").hide();
	$(function() {
		$(window).scroll(function(){
			if ($(window).scrollTop()>500){
				$(".backup").fadeIn(1000);
			}else{
				$(".backup").fadeOut(1000);
			}
		});
	});
/* end index  jq  */
	 $(".leftProClaListUl > li ").click(function(){

		 $(this).next("ul").slideToggle();
		//$(this).toggleClass("open");
	}); 



   $(".mainConList .pic1:nth-child(3n)").css("margin-right","0px");   	
  

   $(".pic2:last-child a").css("border-bottom","none");
   $(".mainConList ul li:last-child").css("border-bottom","none");


    $(".pglist ul li").not(".on").not(".last").not(".next").hover(function(){ $(this).addClass("on");},function(){$(this).removeClass("on");})
	$(".pglist ul li.last").hover(function(){
		  $(this).css({background:"url(/theme/TP000193/images/lastbg2.png) 6px center no-repeat #f2be30",border:"1px solid #f2be30"}).find("a").css({color:"#000000"});
	 },function(){
		   $(this).css({background:"url(/theme/TP000193/images/lastbg.png) 6px center no-repeat #171717",border:"1px solid #171717"}).find("a").css({color:"#b2b2b2"});
	 })
	$(".pglist ul li.next").hover(function(){
		  $(this).css({background:"url(/theme/TP000193/images/nextbg2.png) 56px center no-repeat #f2be30",border:"1px solid #f2be30"}).find("a").css({color:"#000000"});
	 },function(){
		   $(this).css({background:"url(/theme/TP000193/images/nextbg.png) 56px center no-repeat #171717",border:"1px solid #171717"}).find("a").css({color:"#b2b2b2        "});
	 })
	$(".pglist ul li.font").hover(function(){ $(this).css({background:"#a01d1d",color:"#000000",border:"none"});})
  
});



$("document").ready(function(){
	//case
	var page=1;             
	var i=1;
	var box=$('.advPic ul');
	var n=$('.advPic li').length;
	var h=$('.advPic li').width();
	var pagetotal=Math.ceil(n/i);
	$('.picleft').bind('click',upwardsfn);
	$('.picright').bind('click',downfn);	
	function upwardsfn(){
		if(page>1){
			box.animate({ marginLeft : '+='+h }, "slow");
			page--;
			$(".picright").find("img").attr('src','/theme/TP000193/images/advrightb.png');	
			if(page<=1){
				$('.picleft').find("img").attr('src','/theme/TP000193/images/advleftw.png');
			}else{
				$('.picleft').find("img").attr('display','/theme/TP000193/images/advleftb.png');	
			}
		}
	}
	function downfn(){
		if(pagetotal>page){
			box.animate({ marginLeft : '-='+h }, "slow");
			page++;
			$(".picleft").find("img").attr('src','/theme/TP000193/images/advleftb.png');	
			if(page>=pagetotal){
				$('.picright').find("img").attr('src','/theme/TP000193/images/advrightw.png');
			}else{
				$('.picright').find("img").attr('src','/theme/TP000193/images/advrightb.png');	
			}
		}
	}

});

//导航定位
function dingwei(){
	var nav = document.getElementById("nav"); 
	var links = nav.getElementsByTagName("li"); 
	var lilen =$("#nav").find("li");
	
	var st2=new Array();
	var str1=new Array();
	var urrenturl = document.location.href; 	
	  urrenturl = urrenturl.replace("http://","");
	  urrenturlArr = urrenturl.split("/");
	  name = urrenturlArr[urrenturlArr.length-1];
	  st2 = name.split("_");
	var last = 0; 
	for (var i=0;i<links.length;i++) 
	{ 
	    linkurl =  lilen[i].getAttribute("rel"); 
		str1 = linkurl.split("/");
		var length2 = str1.length-1;
		str11 = str1[length2].split(".");
		 if(st2[0].indexOf(str11[0])!=-1) 
			{ 
			 last = i; 
			}
	} 
	links[last].className = "menu";
}
function scrolling(a,b,c){
	var speedp=30;
	var tabp=document.getElementById(a);
	var tab1p=document.getElementById(b);
	var tab2p=document.getElementById(c);
	tab2p.innerHTML=tab1p.innerHTML;
	function Marqueep(){
	if(tab2p.offsetWidth-tabp.scrollLeft<=0)
	tabp.scrollLeft-=tab1p.offsetWidth
	else{
	tabp.scrollLeft++;
	}
	}
	var MyMarp=setInterval(Marqueep,speedp);
	tabp.onmouseover=function() {clearInterval(MyMarp)};
	tabp.onmouseout=function() {MyMarp=setInterval(Marqueep,speedp)};
}

function upscrolling(){
	var speed=40;
	sdemo2.innerHTML = sdemo1.innerHTML;
	function Marquee(){
		if(sdemo2.offsetHeight - sdemo.scrollTop <= 0) {
			sdemo.scrollTop -= sdemo1.offsetHeight;
		} else{
			sdemo.scrollTop++;
		}
	}
	var MyMar = setInterval(Marquee,speed);
	sdemo.onmouseover = function(){ clearInterval(MyMar); }
	sdemo.onmouseout = function(){ MyMar=setInterval(Marquee,speed) }
}
